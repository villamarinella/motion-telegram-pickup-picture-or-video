Tags............
motion, telegram, raspberry pi, raspberry camera, uv4l, security

pickup pictures or videos via telegram from your motion system

you need:
uv4l
motion
telegram
raspberry pi with raspberry camera

One of the best security systems is motion with PI camera.

install uv4l
install motion
configure motion as you need it, must run as daemon!!!!!!!!!!!!
install telegram

Change all files to your belongings, it is easy to understand.
Start motion as daemon with go.sh
Start telegram with -s test.lua

About go.sh
The load from driver raspicam is not neccessary if you install uv4l correct, means you have always /dev/video0
The modprobe, I dont understand but you must run motion as daemon and sometimes you will need it. This was a long story to find it out.....................

If you send !pic or !vid to the rasberry telegram you will receive what you have scripted.

This is a really strong tool!!!!!!!!!!!!
I have in my house about 10 cameras and I am able to control  all of them when ever I want it.

Have fun

For a while, I dont know how long, check my Livecam here
http://www.kwss.ddns.net
or
http://www.kwss.4irc.com/
Username: kamera
Passwort: kwsscoltd

Stay lucky

Klaus Werner







